package accountLogo;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import repository.AccountLogoAvatarRepo;
import repository.MyAccountChangesRepo;

import org.testng.annotations.BeforeTest;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class AccounLogoDPTest
{

	WebDriver driver;
	@BeforeTest
	  public void beforeTest() 
	{
		WebDriverManager.chromedriver().setup();
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		
	  }
	@Test
  public void uploadAvatar() throws Exception
	{
		AccountLogoAvatarRepo.logIn(driver);
		AccountLogoAvatarRepo.un(driver).sendKeys("kajalpawar22@gmail.com");
		AccountLogoAvatarRepo.pwd(driver).sendKeys("Kaju@22");
		AccountLogoAvatarRepo.logInBT(driver).click();
		Thread.sleep(2000);
		AccountLogoAvatarRepo.myAc(driver).click();
		Thread.sleep(1000);
		AccountLogoAvatarRepo.uploadLogo(driver).sendKeys("C:\\Users\\Admin\\Desktop\\IMG_20191206_182341.jpg");
		
		//for invalid file 
		// PDF FILE PATH=== C:\\Users\\Admin\\Desktop\\TestAutomationwithSelenium.pdf
		// Word File Path== C:\\Users\\Admin\\Desktop\\issue.docx
		// Excel File Path== C:\\Users\\Admin\\Desktop\\importContactiLovePdf.xlsx
		
		Thread.sleep(60000);
		
		System.out.println("Account Logo Uploaded.");
		
  }
  

  @AfterTest
  public void afterTest() 
  {
	  driver.close();
  }

}
