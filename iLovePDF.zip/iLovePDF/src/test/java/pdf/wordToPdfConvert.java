package pdf;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import repository.EditPdfRepo;

import org.testng.annotations.BeforeTest;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;

public class wordToPdfConvert 
{
	WebDriver driver;
	@BeforeTest
	  public void beforeTest() 
	{
		WebDriverManager.chromedriver().setup();
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		
	  }
  @Test
  public void f() throws Exception
  {
	  EditPdfRepo.logIn(driver);
		EditPdfRepo.un(driver).sendKeys("kajalpawar22@gmail.com");
		EditPdfRepo.pwd(driver).sendKeys("Kaju@22");
		EditPdfRepo.logInBT(driver).click();
		Thread.sleep(2000);

		Actions ac=new Actions(driver);
		ac.moveToElement(EditPdfRepo.allPDFtools(driver)).build().perform();
	  
		EditPdfRepo.wordToPDF(driver).click();
		Thread.sleep(2000);
		
		EditPdfRepo.selectWordToPDF(driver).click();
		
		Robot rb=new Robot();

		rb.delay(2000);

		StringSelection ss=new  StringSelection("C:\\Users\\Admin\\Desktop\\AssessmentIssue(ByMistakeWindowsClosed).docx");

		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);
		rb.keyPress(KeyEvent.VK_CONTROL);

		rb.keyPress(KeyEvent.VK_V); 
		rb.delay(2000);

		rb.keyRelease(KeyEvent.VK_CONTROL); 
		rb.keyRelease(KeyEvent.VK_V);
		rb.delay(2000);

		rb.keyPress(KeyEvent.VK_ENTER); 
		rb.keyRelease(KeyEvent.VK_ENTER);
		rb.delay(2000);

		Thread.sleep(2000);
		
		EditPdfRepo.convertBtWordToPdf(driver).click();
		Thread.sleep(4000);
		
		WebDriverWait wait=new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.visibilityOf(EditPdfRepo.deleteWordToPdfFile(driver)));
		
	EditPdfRepo.deleteWordToPdfFile(driver).click();
		EditPdfRepo.confirmDeleteWordToPdfFile(driver).click();
		Thread.sleep(2000);
		
		System.out.println(EditPdfRepo.deleteSuccessMsg(driver).getText());
		Thread.sleep(2000);
		
		
		/*
		 * EditPdfRepo.selectFileFromDropBox(driver).click();
		Thread.sleep(2000);
		
		 
		 driver.getWindowHandle();
		 
		driver.getWindowHandles();
		String parentWin=driver.getWindowHandle();
		
		for(String wins:driver.getWindowHandles())

		{
			driver.switchTo().window(wins);
			Thread.sleep(5000);
			
			JavascriptExecutor j=(JavascriptExecutor)driver;
			j.executeScript("arguments[0].value='Kajalpawar22@gmail.com'",  EditPdfRepo.dropBoxEmail(driver));
			//EditPdfRepo.dropBoxEmail(driver).sendKeys("kajalpawar22@gmail.com");
			EditPdfRepo.dropBoxPassword(driver).sendKeys("Kaju@22");
			EditPdfRepo.dropBoxLogin(driver).click();
		}
		/*EditPdfRepo.dropBoxEmail(driver).sendKeys("kajalpawar22@gmail.com");
		EditPdfRepo.dropBoxPassword(driver).sendKeys("Kaju@22");
		EditPdfRepo.dropBoxLogin(driver).click();
		*/
  }
  

  @AfterTest
  public void afterTest() 
  {
	  driver.close();
	  
  }

}
