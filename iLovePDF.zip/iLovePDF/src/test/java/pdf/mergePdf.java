package pdf;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import repository.EditPdfRepo;

import org.testng.annotations.BeforeTest;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;

public class mergePdf
{
	WebDriver driver;
	@BeforeTest
	public void beforeTest() 
	{
		WebDriverManager.chromedriver().setup();
		driver=new ChromeDriver();
		driver.manage().window().maximize();

	}

	@Test
	public void mergePDF() throws Exception
	{
		EditPdfRepo.logIn(driver);
		EditPdfRepo.un(driver).sendKeys("kajalpawar22@gmail.com");
		EditPdfRepo.pwd(driver).sendKeys("Kaju@22");
		EditPdfRepo.logInBT(driver).click();
		Thread.sleep(2000);

		Actions ac=new Actions(driver);
		ac.moveToElement(EditPdfRepo.allPDFtools(driver)).build().perform();
		//EditPdfRepo.allPDFtools(driver).click();

		EditPdfRepo.mergePdf(driver).click();
		EditPdfRepo.selectFilePdf(driver).click();

		// Runtime.getRuntime().exec("C:\\Users\\Admin\\Desktop\\TestAutomationwithSelenium.pdf"+""+"C:\\Users\\\\Admin\\Desktop\\TestAutomationwithSelenium.pdf");


		Robot rb=new Robot();

		rb.delay(2000);

		StringSelection ss=new  StringSelection("C:\\Users\\Admin\\Desktop\\TestAutomationwithSelenium.pdf");

		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);
		rb.keyPress(KeyEvent.VK_CONTROL);

		rb.keyPress(KeyEvent.VK_V); 
		rb.delay(2000);

		rb.keyRelease(KeyEvent.VK_CONTROL); 
		rb.keyRelease(KeyEvent.VK_V);
		rb.delay(2000);

		rb.keyPress(KeyEvent.VK_ENTER); 
		rb.keyRelease(KeyEvent.VK_ENTER);
		rb.delay(2000);

		Thread.sleep(2000);

		//ac.moveToElement(EditPdfRepo.selectAnotherPdf(driver)).click().perform();
		//Thread.sleep(2000);
     	EditPdfRepo.selectAnotherPdf(driver).click();
		//Runtime.getRuntime().exec("C:\\Users\\Admin\\Desktop\\TestAutomationwithSelenium.pdf"+""+"C:\\Users\\Admin\\Desktop\\TestAutomationwithSelenium.pdf");
		Thread.sleep(2000);


		ss=new StringSelection("C:\\Users\\Admin\\Desktop\\TestAutomationwithSelenium.pdf");
		
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);
		rb.keyPress(KeyEvent.VK_CONTROL);

		rb.keyPress(KeyEvent.VK_V); 
		rb.delay(2000);

		rb.keyRelease(KeyEvent.VK_CONTROL); 
		rb.keyRelease(KeyEvent.VK_V);
		rb.delay(2000);

		rb.keyPress(KeyEvent.VK_ENTER); 
		rb.keyRelease(KeyEvent.VK_ENTER);
		rb.delay(2000);
		System.out.println("SecondFile Selected");
		Thread.sleep(2000);
		
		
		EditPdfRepo.selectAnotherPdf(driver).click();
		
		Thread.sleep(2000);


		ss=new StringSelection("C:\\Users\\Admin\\Desktop\\TestAutomationwithSelenium.pdf");
		
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);
		rb.keyPress(KeyEvent.VK_CONTROL);

		rb.keyPress(KeyEvent.VK_V); 
		rb.delay(2000);

		rb.keyRelease(KeyEvent.VK_CONTROL); 
		rb.keyRelease(KeyEvent.VK_V);
		rb.delay(2000);

		rb.keyPress(KeyEvent.VK_ENTER); 
		rb.keyRelease(KeyEvent.VK_ENTER);
		rb.delay(2000);
		System.out.println("ThirdFile Selected");
		Thread.sleep(2000);
		
		
		
		EditPdfRepo.clickMergePdf(driver).click();
		
		WebDriverWait wait =new WebDriverWait(driver, Duration.ofSeconds(30));
		
		wait.until(ExpectedConditions.visibilityOf(EditPdfRepo.clickOnDownLoad(driver)));
		 
		
		//System.out.println(EditPdfRepo.fileMergedMSG(driver).getText());
		Thread.sleep(2000);
		
		JavascriptExecutor jse=(JavascriptExecutor)driver;
		jse.executeScript("arguments[0].click();", EditPdfRepo.clickOnDownLoad(driver));
		
		//EditPdfRepo.clickOnDownLoad(driver).click();
		Thread.sleep(2000);
		//System.out.println(EditPdfRepo.fileMergedMSG(driver).getText());
		
			}


	@AfterTest
	public void afterTest() 
	{
			driver.close();
	}

}
