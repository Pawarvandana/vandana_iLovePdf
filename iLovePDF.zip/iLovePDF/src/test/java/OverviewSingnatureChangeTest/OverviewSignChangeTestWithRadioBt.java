package OverviewSingnatureChangeTest;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import repository.OverviewWithRadioBtRepo;

import org.testng.annotations.BeforeTest;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterTest;

public class OverviewSignChangeTestWithRadioBt 
{
	WebDriver driver;
	@BeforeTest
	public void beforeTest() 
	{
		WebDriverManager.chromedriver().setup();
		driver=new ChromeDriver();
		driver.manage().window().maximize();

	}
	@Test
	public void overviewSignature() throws Exception
	{
		OverviewWithRadioBtRepo.login(driver);
		OverviewWithRadioBtRepo.email(driver).sendKeys("Kajalpawar22@gmail.com");
		OverviewWithRadioBtRepo.pass(driver).sendKeys("Kaju@22");
		OverviewWithRadioBtRepo.loginBT(driver).click();
		OverviewWithRadioBtRepo.myAc(driver).click();
		OverviewWithRadioBtRepo.scrollToBottom(driver);
		Thread.sleep(2000);
		OverviewWithRadioBtRepo.clickOverview(driver).click();
		OverviewWithRadioBtRepo.signatureSetting(driver).click();
		Thread.sleep(2000);


		OverviewWithRadioBtRepo.fullName(driver).clear();
		OverviewWithRadioBtRepo.fullName(driver).sendKeys("Vandana Pawar");

		Actions ac=new Actions(driver);
		ac.scrollToElement(OverviewWithRadioBtRepo.scrollTill(driver)).perform();
		Thread.sleep(2000);

		JavascriptExecutor js= (JavascriptExecutor)driver;
		js.executeScript("arguments[0].click();", OverviewWithRadioBtRepo.radioSignature(driver));
		
		//OverviewWithRadioBtRepo.radioSignature(driver).click();
		
		System.out.println("Signature selected");
		OverviewWithRadioBtRepo.selectColor(driver).click();
		Thread.sleep(2000);
		OverviewWithRadioBtRepo.applyBt(driver).click();

	}


	@AfterTest
	public void afterTest() 
	{
			driver.close();
	}

}
