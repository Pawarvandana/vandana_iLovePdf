package OverviewSingnatureChangeTest;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import repository.OverviewWithRadioBtRepo;

import org.testng.annotations.BeforeTest;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterTest;

public class OverviewSignChangeWithDrawing 
{
	WebDriver driver;
	
	 @BeforeTest
	  public void beforeTest() 
	 {
		   WebDriverManager.chromedriver().setup();
			driver=new ChromeDriver();
			driver.manage().window().maximize();
	 }
  @Test
  public void drawSignature() throws Exception
  {
	    OverviewWithRadioBtRepo.login(driver);
		OverviewWithRadioBtRepo.email(driver).sendKeys("Kajalpawar22@gmail.com");
		OverviewWithRadioBtRepo.pass(driver).sendKeys("Kaju@22");
		OverviewWithRadioBtRepo.loginBT(driver).click();
		OverviewWithRadioBtRepo.myAc(driver).click();
		OverviewWithRadioBtRepo.scrollToBottom(driver);
		Thread.sleep(2000);
		OverviewWithRadioBtRepo.clickOverview(driver).click();
		OverviewWithRadioBtRepo.signatureSetting(driver).click();
		Thread.sleep(2000);
		if (OverviewWithRadioBtRepo.deletDrawnSign(driver).isDisplayed())
		{
			OverviewWithRadioBtRepo.deletDrawnSign(driver).click();
		}
		Thread.sleep(2000);
		
		JavascriptExecutor j=(JavascriptExecutor)driver;
		j.executeScript("arguments[0].click();", OverviewWithRadioBtRepo.drawSign(driver));
		Thread.sleep(2000);
		OverviewWithRadioBtRepo.drawSignColor(driver).click();
		Thread.sleep(2000);
		
		WebElement element=OverviewWithRadioBtRepo.drawYourSign(driver);
		
		Actions act=new Actions(driver);
		  //act.dragAndDropBy(element, 200, 50).build().perform();
		  
		  act.moveToElement(element).perform();
		  act.clickAndHold(element).perform();
		  act.moveByOffset(150, 50).perform();
		  act.moveToElement(element).perform();
		  act.clickAndHold(element).perform();
		  act.moveByOffset(100, 50).perform();
		  act.moveToElement(element).perform();
		
		//OverviewWithRadioBtRepo.drawYourSign(driver);
		Thread.sleep(1000);
		OverviewWithRadioBtRepo.applyBt(driver).click();
		Thread.sleep(4000);
		
  }
 

  @AfterTest
  public void afterTest() 
  {
	  System.out.println("Signature Drawn.");
	  driver.close();
	  
  }

}
