package OverviewSingnatureChangeTest;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import repository.OverviewWithRadioBtRepo;

import org.testng.annotations.BeforeTest;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class UplodingSignatureTest 
{
	WebDriver driver;
	
	
	@BeforeTest
	  public void beforeTest() 
	{
		WebDriverManager.chromedriver().setup();
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		
	 }
  @Test
  public void uploadSign() throws Exception
  {
	    OverviewWithRadioBtRepo.login(driver);
		OverviewWithRadioBtRepo.email(driver).sendKeys("Kajalpawar22@gmail.com");
		OverviewWithRadioBtRepo.pass(driver).sendKeys("Kaju@22");
		OverviewWithRadioBtRepo.loginBT(driver).click();
		OverviewWithRadioBtRepo.myAc(driver).click();
		OverviewWithRadioBtRepo.scrollToBottom(driver);
		Thread.sleep(2000);
		OverviewWithRadioBtRepo.clickOverview(driver).click();
		OverviewWithRadioBtRepo.signatureSetting(driver).click();
		Thread.sleep(2000);
		
		OverviewWithRadioBtRepo.uploadBt(driver).click();
		Thread.sleep(2000);
		
		
		 if(OverviewWithRadioBtRepo.deletUploadedSign(driver).isDisplayed()) 
		 {
		  OverviewWithRadioBtRepo.deletUploadedSign(driver).click();
		  Thread.sleep(2000);
		  
		  }
		  
		  
		 else 
		  { 
			  System.out.println("Signature File not uploaded.");
		  
		  }
		 
		  OverviewWithRadioBtRepo.uploadSignFile(driver).click();
		  Robot rb=new Robot();
		  
		  rb.delay(2000);
		  
		  StringSelection ss=new
		  StringSelection("C:\\Users\\Admin\\Desktop\\SignatureFile.jpg");
		 Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);
		  rb.keyPress(KeyEvent.VK_CONTROL);
		  
		  rb.keyPress(KeyEvent.VK_V); rb.delay(2000);
		  
		  rb.keyRelease(KeyEvent.VK_CONTROL); rb.keyRelease(KeyEvent.VK_V);
		  rb.delay(2000);
		  
		  rb.keyPress(KeyEvent.VK_ENTER); rb.keyRelease(KeyEvent.VK_ENTER);
		  rb.delay(2000);
		  
		  Thread.sleep(3000);
		  System.out.println("Signature File Uploaded.");
		
		//sendKeys("C:\\Users\\Admin\\Desktop\\SignatureFile.jpg");
		 OverviewWithRadioBtRepo.applyBt(driver).click();
		 Thread.sleep(2000);
  }
  

  @AfterTest
  public void afterTest() 
  {
	  
	  driver.close();
	  
  }

}
