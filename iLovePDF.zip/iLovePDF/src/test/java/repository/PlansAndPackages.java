package repository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class PlansAndPackages 
{

static WebElement element;
	
	public static void login(WebDriver driver) 
	{
		driver.get("https://www.ilovepdf.com/login");
	}

	public static WebElement email(WebDriver driver) 
	{
		element = driver.findElement(By.id("loginEmail"));
		return element;
	}

	public static WebElement pass(WebDriver driver) 
	{
		element = driver.findElement(By.id("inputPasswordAuth"));
		return element;
	}

	public static WebElement loginBT(WebDriver driver) 
	{
		element = driver.findElement(By.id("loginBtn"));
		return element;
	}
	
	public static WebElement myAc(WebDriver driver) 
	{
		element=driver.findElement(By.xpath("/html/body/div[1]/div/div[5]/ul/li[1]/a"));
		return element;
		
	}
	
	public static WebElement scrollDown(WebDriver driver) 
	{
		element=driver.findElement(By.linkText("Invoices"));
		return element;
		
	}
	
//	cLIck Plans & Packages
	// Add More Signature
	public static WebElement clickPlanPackage(WebDriver driver) 
	{
		element=driver.findElement(By.linkText("Plans & Packages"));
		return element;
		
	}
	
	public static WebElement clickAddMoreSign(WebDriver driver) 
	{
		element=driver.findElement(By.xpath("//*[@id=\"mainAdmin\"]/div[2]/div[3]/div[2]/div/div/div/div[2]/ul/li[1]/div[2]"));
		return element;
		
	}
	
	/*
	 * public static WebElement ListSign(WebDriver driver, int i) {
	 * element=driver.findElement(By.xpath(
	 * "/html/body/div[5]/div[1]/div[1]/main/div[2]/div/div/div[2]/div[2]/div/div[1]["
	 * +i+"]"));
	 * 
	 * 
	 * return element;
	 * 
	 * }
	 */
	
	
	public static WebElement listSign1(WebDriver driver) 
	{
		element=driver.findElement(By.xpath("//*[@id=\"SelectSignatures\"]/div/div[1]/span[1]"));
		
		
		return element;
		
	}
	
	public static WebElement listSign2(WebDriver driver) 
	{
		element=driver.findElement(By.xpath("/html/body/div[5]/div[1]/div[1]/main/div[2]/div/div/div[2]/div[2]/div/div[1]/span[2]"));
		
		return element;
		
	}
	
	
	public static WebElement listSign3(WebDriver driver) 
	{
		//element=driver.findElement(By.xpath("//*[@id=\"SelectSignatures\"]/div/div[1]/span[3]"));
		element= driver.findElement(By.xpath("/html/body/div[5]/div[1]/div[1]/main/div[2]/div/div/div[2]/div[2]/div/div[1]/span[3]"));
		return element;
		
	}
	
	
	
	
	public static WebElement listSign4(WebDriver driver) 
	{
		element=driver.findElement(By.xpath("//*[@id=\"SelectSignatures\"]/div/div[1]/span[4]"));
		return element;
		
	}
	
	public static WebElement listSign5(WebDriver driver) 
	{
		element=driver.findElement(By.xpath("//*[@id=\"SelectSignatures\"]/div/div[1]/span[5]"));
		return element;
		
	}
	public static WebElement listSign6(WebDriver driver) 
	{
		element=driver.findElement(By.xpath("//*[@id=\"SelectSignatures\"]/div/div[1]/span[6]"));
		return element;
		
	}
	public static WebElement listSign7(WebDriver driver) 
	{
		element=driver.findElement(By.xpath("//*[@id=\"SelectSignatures\"]/div/div[1]/span[7]"));
		return element;
		
	}
	//dialog__close
	
	public static WebElement closeListSign(WebDriver driver) 
	{
		element=driver.findElement(By.xpath("/html/body/div[5]/div[1]/div[1]/main/div[2]/div/div/div[1]/div[3]"));
		return element;
		
	}
	
	
	// Add more SMS
	
	
	public static WebElement clickListSMS(WebDriver driver) 
	{
		element=driver.findElement(By.xpath("//*[@id=\"mainAdmin\"]/div[2]/div[3]/div[2]/div/div/div/div[2]/ul/li[2]/div[2]"));
		//*[@id="mainAdmin"]/div[2]/div[3]/div[2]/div/div/div/div[2]/ul/li[2]/div[2]
		return element;
		
	}
	
	// /html/body/div[5]/div[1]/div[1]/main/div[1]/div/div/div[1]/div[1]
	public static WebElement validationSMS(WebDriver driver) 
	{
		element=driver.findElement(By.xpath("/html/body/div[5]/div[1]/div[1]/main/div[1]/div/div/div[1]/div[1]"));
		//*[@id="mainAdmin"]/div[2]/div[3]/div[2]/div/div/div/div[2]/ul/li[2]/div[2]
		return element;
		
	}
	
	
	public static WebElement listSMS1(WebDriver driver) 
	{
		element=driver.findElement(By.xpath("//*[@id=\"SelectSMS\"]/div/div[1]/span[1]"));
		return element;
		
	}
	
	public static WebElement listSMS2(WebDriver driver) 
	{
		element=driver.findElement(By.xpath("//*[@id=\"SelectSMS\"]/div/div[1]/span[2]"));
		return element;
		
	}
	
	public static WebElement listSMS3(WebDriver driver) 
	{
		element=driver.findElement(By.xpath("//*[@id=\"SelectSMS\"]/div/div[1]/span[3]"));
		return element;
		
	}
	public static WebElement listSMS4(WebDriver driver) 
	{
		element=driver.findElement(By.xpath("//*[@id=\"SelectSMS\"]/div/div[1]/span[4]"));
		return element;
		
	}
	
	public static WebElement listSMS5(WebDriver driver) 
	{
		element=driver.findElement(By.xpath("//*[@id=\"SelectSMS\"]/div/div[1]/span[5]"));
		return element;
		
	}
	
	public static WebElement listSMS6(WebDriver driver) 
	{
		element=driver.findElement(By.xpath("//*[@id=\"SelectSMS\"]/div/div[1]/span[6]"));
		return element;
		
	}
	
	public static WebElement listSMS7(WebDriver driver) 
	{
		element=driver.findElement(By.xpath("//*[@id=\"SelectSMS\"]/div/div[1]/span[7]"));
		return element;
		
	}
	
	
	public static WebElement closeListSMS2(WebDriver driver) 
	{
		element=driver.findElement(By.xpath("/html/body/div[5]/div[1]/div[1]/main/div[1]/div/div/div[1]/div[3]"));
		return element;
		
	}
	
	public static WebElement processToCheck(WebDriver driver) 
	{
		element=driver.findElement(By.xpath("/html/body/div[5]/div[1]/div[1]/main/div[2]/div/div/div[2]/div[3]/button"));
		return element;
		
	}
	
	
	public static WebElement cardNo(WebDriver driver) 
	
	{
		element=driver.findElement(By.name("cardnumber"));
		//element=driver.findElement(By.xpath("//*[@id=\"root\"]/form/div/div[2]/span[1]/span[2]/div"));
		return element;
		
	}
	
	public static WebElement confirmPayment(WebDriver driver) 
	{
		element=driver.findElement(By.xpath("/html/body/div[5]/div[1]/div[1]/main/div[4]/div[1]/div/div[1]/div[5]/div/div[2]/div[1]/div/div/div[3]/button"));
		return element;
		
	}
	
	
	public static WebElement pay(WebDriver driver) 
	{
		element=driver.findElement(By.className("summary__title"));
		return element;
		
	}
	
	public static WebElement payFrame(WebDriver driver) 
	{
		element=driver.findElement(By.xpath("/html/body/div[5]/div[1]/div[1]/main/div[4]/div[1]/div/div[1]/div[5]/div/div[2]/div[1]/div/div/div[2]/div[2]/div/iframe"));
		return element;
		
	}
	
// /html/body/div[5]/div[1]/div[1]/main/div[4]/div[1]/div/div[1]/div[5]/div/div[2]/div[1]/div/div/div[2]/div[4]
	
	public static WebElement confirmPayMsg(WebDriver driver) 
	{
		element=driver.findElement(By.xpath("/html/body/div[5]/div[1]/div[1]/main/div[4]/div[1]/div/div[1]/div[5]/div/div[2]/div[1]/div/div/div[2]/div[4]"));
		return element;
		
	}
//	dialog__back
	
	public static WebElement backToPayFram(WebDriver driver) 
	{
		element=driver.findElement(By.className("dialog__back"));
		return element;
		
	}
	
	public static WebElement closePayFrame(WebDriver driver) 
	{
		element=driver.findElement(By.className("dialog__close"));
		return element;
		
	}
	//dialog__close
	//summary__title
}
