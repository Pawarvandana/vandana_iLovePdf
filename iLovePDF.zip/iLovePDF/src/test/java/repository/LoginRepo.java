package repository;

import java.sql.Driver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginRepo {
	static WebElement element;

	public static void WebLik(WebDriver driver) 
	{
		driver.get("https://www.ilovepdf.com/");

	}

	public static WebElement login(WebDriver driver) 
	{
		element = driver.findElement(By.linkText("Log in"));
		return element;

	}

	public static WebElement email(WebDriver driver) 
	{
		element = driver.findElement(By.id("loginEmail"));
		return element;
	}

	public static WebElement pass(WebDriver driver) 
	{
		element = driver.findElement(By.id("inputPasswordAuth"));
		return element;
	}

	public static WebElement loginBT(WebDriver driver) 
	{
		element = driver.findElement(By.id("loginBtn"));
		return element;
	}

	public static WebElement welcomeAdmin(WebDriver driver) 
	{
		element = driver.findElement(By.xpath("/html/body/div[1]/div/div[5]/ul/li[1]"));
		return element;
	}

	
	  public static WebElement logOut(WebDriver driver) 
	  { 
		  element=driver.findElement(By.linkText("Log Out")); 

		  return element;
	  }
	  
	  
	  
	 
	 
}
