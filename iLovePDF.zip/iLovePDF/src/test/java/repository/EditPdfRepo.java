package repository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class EditPdfRepo
{
 
	static WebElement element;
	public static void logIn(WebDriver driver) 
	{
	 driver.get("https://www.ilovepdf.com/login");
	
		
	}
	public static WebElement un(WebDriver driver) 
	{
		element =driver.findElement(By.id("loginEmail"));
		
		return element;
		
	}
	public static WebElement pwd(WebDriver driver) 
	{
		element = driver.findElement(By.id("inputPasswordAuth"));
		
		return element;
		
		
	}
	public static WebElement logInBT(WebDriver driver) 
	{
		element=driver.findElement(By.id("loginBtn"));
		return element;
	}
	
	
	
	public static WebElement allPDFtools(WebDriver driver) 
	{
		element=driver.findElement(By.id("menuSmall"));
		return element;
	}
	
	//Merge PDF
	public static WebElement mergePdf(WebDriver driver) 
	{
		element=driver.findElement(By.cssSelector("a[href='/merge_pdf\']"));
		return element;
	}
	
	
	public static WebElement selectFilePdf(WebDriver driver) 
	{
		element=driver.findElement(By.id("pickfiles"));
		return element;
	}
//	uploader__btn tooltip--left active tooltip
	
	public static WebElement selectAnotherPdf(WebDriver driver) 
	{
		element=driver.findElement(By.cssSelector("a[class='uploader__btn tooltip--left active tooltip']"));
		return element;
	}
	public static WebElement clickMergePdf(WebDriver driver) 
	{
		element=driver.findElement(By.id("processTask"));
		return element;
	}
	
	// /html/body/div[2]/div[2]/div/div[3] Merged file Downloading
	public static WebElement mergedFileDownload(WebDriver driver) 
	{
		element=driver.findElement(By.xpath("/html/body/div[2]/div[2]/div/div[3]"));
		return element;
	}
	
	// /html/body/div[2]/div[1]/div[1]/h1
	
	public static WebElement fileMergedMSG(WebDriver driver) 
	{
		element=driver.findElement(By.xpath("/html/body/div[2]/div[1]/div[1]/h1"));
		return element;
	}
	

//    Download merged PDF     
	public static WebElement clickOnDownLoad(WebDriver driver) 
	{
		element=driver.findElement(By.xpath("//*[@id=\"pickfiles\"]"));
		return element;
	}
	
	
//	WORD to PDF
	
	public static WebElement wordToPDF(WebDriver driver) 
	{
		element=driver.findElement(By.linkText("WORD to PDF"));
		return element;
	}
	
	//pickfiles
	public static WebElement selectWordToPDF(WebDriver driver) 
	{
		element=driver.findElement(By.id("pickfiles"));
		return element;
	}
	
	public static WebElement convertBtWordToPdf(WebDriver driver) 
	{
		element=driver.findElement(By.id("processTaskTextBtn"));
		return element;
	}
	
	public static WebElement deleteWordToPdfFile(WebDriver driver) 
	{
		element=driver.findElement(By.id("delete"));
		return element;
	}
	//btnDelete
	public static WebElement confirmDeleteWordToPdfFile(WebDriver driver) 
	{
		element=driver.findElement(By.id("btnDelete"));
		return element;
	}
	
	// /html/body/div[2]/div[1]/div[1]/h1
	
	public static WebElement deleteSuccessMsg(WebDriver driver) 
	{
		element=driver.findElement(By.xpath("/html/body/div[2]/div[1]/div[1]/h1"));
		return element;
	}
	
	// PDF TO Excel
	// PDF to EXCEL
	 public static WebElement pdfToExcel(WebDriver driver) 
		{
			element=driver.findElement(By.xpath("//*[@id=\"menuSmall\"]/ul/li[4]/ul/li[5]/a"));
			return element;
		}
	public static WebElement selectFileFromDropBox(WebDriver driver) 
	{
		element=driver.findElement(By.id("dropbox_file_selector"));
		return element;
	}
	
	
	
	
	//login_email
	
	public static WebElement dropBoxEmail(WebDriver driver) 
	{
		element=driver.findElement(By.id("login_email"));
		return element;
	}
	
	//login_password
	
	public static WebElement dropBoxPassword(WebDriver driver) 
	{
		element=driver.findElement(By.id("login_password"));
		return element;
	}
	
	//*[@id="right-gray"]/div/div/div[1]/div[2]/div/div/form/div[2]/div[1]/button
	
	public static WebElement dropBoxLogin(WebDriver driver) 
	{
		element=driver.findElement(By.id("//*[@id=\"right-gray\"]/div/div/div[1]/div[2]/div/div/form/div[2]/div[1]/button"));
		return element;
	}
}
