package repository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class AccountLogoAvatarRepo
{
	static WebElement element;
	public static void logIn(WebDriver driver) 
	{
	 driver.get("https://www.ilovepdf.com/login");
	
		
	}
	public static WebElement un(WebDriver driver) 
	{
		element =driver.findElement(By.id("loginEmail"));
		
		return element;
		
	}
	public static WebElement pwd(WebDriver driver) 
	{
		element = driver.findElement(By.id("inputPasswordAuth"));
		
		return element;
		
		
	}
	public static WebElement logInBT(WebDriver driver) 
	{
		element=driver.findElement(By.id("loginBtn"));
		return element;
	}
	
	public static WebElement myAc(WebDriver driver) 
	{
		element=driver.findElement(By.xpath("/html/body/div[1]/div/div[5]/ul/li[1]/a"));
		return element;
		
	}
	//uploadAvatar
	public static WebElement uploadLogo(WebDriver driver) 
	{
		element=driver.findElement(By.id("uploadAvatar"));
		return element;
	}

}
