package repository;

import java.sql.Driver;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class MyAccountChangesRepo 
{
	static WebElement element;
	public static void logIn(WebDriver driver) 
	{
	 driver.get("https://www.ilovepdf.com/login");
	
		
	}
	public static WebElement un(WebDriver driver) 
	{
		element =driver.findElement(By.id("loginEmail"));
		
		return element;
		
	}
	public static WebElement pwd(WebDriver driver) 
	{
		element = driver.findElement(By.id("inputPasswordAuth"));
		
		return element;
		
		
	}
	public static WebElement logInBT(WebDriver driver) 
	{
		element=driver.findElement(By.id("loginBtn"));
		return element;
		
	}
	public static WebElement myAc(WebDriver driver) 
	{
		element=driver.findElement(By.xpath("/html/body/div[1]/div/div[5]/ul/li[1]/a"));
		return element;
		
	}
	public static  WebElement clickChange(WebDriver driver) 
	{
		element=driver.findElement(By.xpath("//*[@id=\"account-preview\"]/div[1]/span"));
		return element;
		
	}
	
	public static WebElement scrollTo(WebDriver driver) 
	{
		element=driver.findElement(By.id("save-btn"));
		 
		return element;
	}
	
	public static WebElement profileName(WebDriver driver) 
	{
		element=driver.findElement(By.id("updateuserform-name"));
		return element;
	}
	
	public static WebElement profileSurname(WebDriver driver) 
	{
		element=driver.findElement(By.id("updateuserform-surname"));
		return element;
	}
	
	public static WebElement country(WebDriver driver) 
	{
		element = driver.findElement(By.id("updateuserform-country_id"));
		
		return element;
	}
	
	public static  WebElement timeZone(WebDriver driver) 
	{
	element=driver.findElement(By.id("updateuserform-timezone"));
		
		return element;
		
	}
	
	public static WebElement saveBtn(WebDriver driver) 
	{
		element=driver.findElement(By.id("save-btn"));
		return element;
		
	}
	public static WebElement msg(WebDriver driver) 
	  {
		  element=driver.findElement(By.xpath("//*[@id=\"mainAdmin\"]/div[2]/div[2]/div/div[1]/ul/li"));
		  return element; 
		
	}
	
	
	// EDIT MAIL ROBOT Tick Handling
	
	
	public static WebElement emailEditBt(WebDriver driver) 
	  {
		  element=driver.findElement(By.id("email-change-btn"));
		  return element; 
		
	}
	
	///html/body/div[3]/div
	
	public static WebElement scrollToBottom(WebDriver driver) 
	  {
		  element=driver.findElement(By.xpath("/html/body/div[3]/div"));
		  return element; 
		
	}
	

	//updateemailform-password
	
	public static WebElement currentPass(WebDriver driver) 
	  {
		  element=driver.findElement(By.id("updateemailform-password"));
		  return element; 
		
	}
	
	public static WebElement newEmail(WebDriver driver) 
	  {
		  element=driver.findElement(By.id("updateemailform-email"));
		  return element; 
		
	}
	
	public static WebElement reEnterNewEmail(WebDriver driver) 
	  {
		  element=driver.findElement(By.id("updateemailform-email_repeat"));
		  return element; 
		
	}
	
	//save-btn Save BT
	public static WebElement saveBtEmail(WebDriver driver) 
	  {
		  element=driver.findElement(By.xpath("//*[@id=\"save-btn\"]"));
		  return element; 
		
	}
	
	//*[@id="mainAdmin"]/div[2]/div[2]/div/div[1] email Updated
	
	public static WebElement updateEmail(WebDriver driver) 
	  {
		  element=driver.findElement(By.xpath("//*[@id=\"mainAdmin\"]/div[2]/div[2]/div/div[1]"));
		  return element; 
		
	}
	
	
	
	
	
}
