package repository;

import java.sql.Driver;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Contact 
{

static WebElement element;
static List<WebElement> el;
	
	public static void login(WebDriver driver) 
	{
		driver.get("https://www.ilovepdf.com/login");
	}

	public static WebElement email(WebDriver driver) 
	{
		element = driver.findElement(By.id("loginEmail"));
		return element;
		
	}

	public static WebElement pass(WebDriver driver) 
	{
		element = driver.findElement(By.id("inputPasswordAuth"));
		return element;
	}

	public static WebElement loginBT(WebDriver driver) 
	{
		element = driver.findElement(By.id("loginBtn"));
		return element;
	}
	
	public static WebElement myAc(WebDriver driver) 
	{
		element=driver.findElement(By.xpath("/html/body/div[1]/div/div[5]/ul/li[1]/a"));
		return element;
		
	}
	
	public static WebElement scrollDown(WebDriver driver) 
	{
		element=driver.findElement(By.linkText("Invoices"));
		return element;
		
	}
	
	//  /////////////Contact Module \\\\\\\\\\
	
	public static WebElement clickContact(WebDriver driver) 
	{
		element=driver.findElement(By.linkText("Contacts"));
		return element;
	}
	// %%%%%%%%Add Contact%%%%%%%%%%%
	
	public static WebElement addContact(WebDriver driver) 
	{
		element=driver.findElement(By.linkText("Add contact"));
		return element;
	}
	
	public static WebElement conName(WebDriver driver) 
	{
		element=driver.findElement(By.name("contacts[0][name]"));
		return element;
		
	}
	
	public static WebElement conEmail(WebDriver driver) 
	{
		element=driver.findElement(By.name("contacts[0][email]"));
		return element;
		
	}
	
	public static WebElement conPhone(WebDriver driver) 
	{
		element=driver.findElement(By.name("contacts[0][phone]"));
		return element;
		
	}
	public static WebElement contactCreate(WebDriver driver) 
	{
		element=driver.findElement(By.xpath("//*[@id=\"agendaAddForm\"]/div[3]/button[2]"));
		return element;
		
	}
	
	
	public static WebElement ConfirmConCreated(WebDriver driver) 
	{
		element=driver.findElement(By.xpath("//*[@id=\"mainAdmin\"]/div[2]/div[2]/div/div[1]"));
		return element;
		
	}
	
	// #######  Import Contacts#####
	
	public static WebElement impConFile(WebDriver driver) 
	{
		element=driver.findElement(By.linkText("Import contacts"));
		return element;
		
	}
	public static WebElement impConUpload(WebDriver driver) 
	{
		element=driver.findElement(By.id("contactUpload"));
		return element;
		
	}
	
	
	
	public static WebElement ConUploadedMSG(WebDriver driver) 
	{
		element=driver.findElement(By.xpath("//*[@id=\"mainAdmin\"]/div[2]/div[2]/div/div[1]"));
		return element;
		
	}
	
	public static WebElement ConNotUpload(WebDriver driver) 
	{
		element=driver.findElement(By.xpath("//*[@id=\"mainAdmin\"]/div[2]/div[2]/div/div[1]"));
		return element;
		
	}
	
	//########### Search Contact#######
	
	public static WebElement searchCon(WebDriver driver) 
	{
		element=driver.findElement(By.name("search_string"));
		return element;
			
	}
	
	public static WebElement invalidData(WebDriver driver) 
	{
		element=driver.findElement(By.xpath("//*[@id=\"mainAdmin\"]/div[2]/div[3]/div/div/div[3]/small"));
		return element;
			
	}
	
	
	/// Search WITH Edit And delete data
	
	public static WebElement editContactInfo(WebDriver driver) 
	{
		element=driver.findElement(By.xpath("//*[@id=\"mainAdmin\"]/div[2]/div[3]/div/div/div[1]/h2"));
		return element;
			
	}
	
	
	
	public static WebElement editContactBT(WebDriver driver) 
	{
		element=driver.findElement(By.className("contacts-agenda__link"));
		
		//contacts-agenda__link
		return element;
			
	}
	
	//*[@id="contact-info-edit"]/div[1]/h2
	public static WebElement contactInfoChangeWindow(WebDriver driver) 
	{
		element=driver.findElement(By.xpath("//*[@id=\"contact-info-edit\"]/div[1]/h2"));
		return element;
			
	}
	
	public static WebElement contactInfoChange(WebDriver driver) 
	{
		element=driver.findElement(By.id("contact-info-change-btn"));
		return element;
			
	}
	
	public static WebElement contactInfoChangeName(WebDriver driver) 
	{
		element=driver.findElement(By.name("contact[name]"));
		return element;
			
	}
	public static WebElement contactInfoChangeSaveBt(WebDriver driver) 
	{
		element=driver.findElement(By.xpath("/html/body/div[2]/div/div[2]/div[3]/div/div[2]/div[2]/form/div/button"));
		return element;
			
	}
	//*[@id="contact-info-edit"]/div[1]/h2  BACK
	public static WebElement backToContactSearchPg(WebDriver driver) 
	{
		element=driver.findElement(By.xpath("/html/body/div[2]/div/div[2]/div[1]/div[1]/div/div/div/a"));
		return element;
			
	}
	
	//*[@id="contactsForm"]/table/tbody/tr/td[6]/div/div[1]/svg/use DELECT
	
	public static WebElement deleteSearchedCon(WebDriver driver) 
	{
		element=driver.findElement(By.xpath("//*[@id=\"contactsForm\"]/table/tbody/tr/td[6]/div/div[1]"));
		return element;
			
	}
	
	//deleteOneModal-secondary-btn Do you want dto remove this contact? FOR == NO
	public static WebElement doNotDelete(WebDriver driver) 
	{
		element=driver.findElement(By.id("deleteOneModal-secondary-btn"));
		return element;
			
	}
	
	//*[@id="mainAdmin"]/div[2]/div[2]/div/div[1]/ul/li Contact Removed
	
	public static WebElement contactRemoved(WebDriver driver) 
	{
		element=driver.findElement(By.xpath("//*[@id=\"mainAdmin\"]/div[2]/div[2]/div/div[1]/ul/li"));
		return element;
			
	}
	
	//deleteOneModal-primary-btn Do you want to remove this contact == Yes
	public static WebElement yesDelete(WebDriver driver) 
	{
		element=driver.findElement(By.id("deleteOneModal-primary-btn"));
		return element;
			
	}
	
	//*[@id="mainAdmin"]/div[2]/div[3]/div/div/div[3]/small No data
	
	public static WebElement noDataAvailabel(WebDriver driver) 
	{
		element=driver.findElement(By.xpath("//*[@id=\"contactsForm\"]/table/tbody/tr/td[6]/div/div[1]"));
		return element;
			
	}
	
	
 	// FOR delect CONTACT contact[phone]
	
	public static WebElement contactInfoDelete(WebDriver driver) 
	{
		element=driver.findElement(By.name("contact[phone]"));
		return element;
			
	}
	
	
	//*[@id="mainAdmin"]/div[2]/div[2]/div/div[1]/ul
	
	public static WebElement contactInfoChangeSuccessMsg(WebDriver driver) 
	{
		element=driver.findElement(By.xpath("//*[@id=\"mainAdmin\"]/div[2]/div[2]/div/div[1]/ul/li"));
		return element;
			
	}
	
	
	
	// @@@@@@@@@@@@@Table Handling @@@@@@@@
	
	
	
	public static List<WebElement> tableRow(WebDriver driver) 
	{
		el=driver.findElements(By.xpath("//*[@id=\"contactsForm\"]/table/tbody/tr[1]/td"));
		return el;
			
	}
	
	public static List<WebElement> tableColumns(WebDriver driver) 
	{
		el=driver.findElements(By.xpath("//*[@id=\"contactsForm\"]/table/tbody/tr"));
		
		return el;
			
	}
	
	
public static WebElement table(WebDriver driver, int i , int j) 
	{
		
		 element=driver.findElement(By.xpath("//*[@id=\"contactsForm\"]/table/tbody/tr["+ i +"]/td[" + j + "]"));
		return element;
		
	
			
	}
	
	
	
	
	
}
