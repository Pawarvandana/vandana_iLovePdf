package repository;

import java.sql.Driver;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.events.EventFiringWebDriver;

public class OverviewWithRadioBtRepo 
{
	static WebElement element;
	
	public static void login(WebDriver driver) 
	{
		driver.get("https://www.ilovepdf.com/login");
	}

	public static WebElement email(WebDriver driver) 
	{
		element = driver.findElement(By.id("loginEmail"));
		return element;
	}

	public static WebElement pass(WebDriver driver) 
	{
		element = driver.findElement(By.id("inputPasswordAuth"));
		return element;
	}

	public static WebElement loginBT(WebDriver driver) 
	{
		element = driver.findElement(By.id("loginBtn"));
		return element;
	}
	
	public static WebElement myAc(WebDriver driver) 
	{
		element=driver.findElement(By.xpath("/html/body/div[1]/div/div[5]/ul/li[1]/a"));
		return element;
		
	}
	
	
	public static WebElement scrollToBottom(WebDriver driver) 
	{
		element=driver.findElement(By.linkText("Contacts"));
		
		JavascriptExecutor js= (JavascriptExecutor)driver;
		js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
		
		return element;
	}
	
	public static WebElement clickOverview(WebDriver driver) 
	{
		element=driver.findElement(By.linkText("Overview"));
		return element;
		
	}
	public static WebElement signatureSetting(WebDriver driver) 
	{
		element=driver.findElement(By.xpath("//*[@id=\"openSignatureConfig\"]/div[2]"));
		return element;
	}
	
	public static WebElement fullName(WebDriver driver) {
		 element=driver.findElement(By.id("signName"));
		  
		  return element;
	}
	
	 public static WebElement scrollTill(WebDriver driver) 
	 {
		 element =driver.findElement(By.xpath("//*[@id=\"signatureFont\"]/ul/li[6]")); 
		  return element;
	  
	  }
	  

	 
	 public static WebElement radioSignature(WebDriver driver) 
	  {
		  
		 element=driver.findElement(By.id("signature-font-mark"));
		 return element;
	  }
	 
	
	 public static WebElement selectColor(WebDriver driver) 
	 {
		 element=driver.findElement(By.xpath("//*[@id=\"signatureFont\"]/div/div[3]"));
		
		 return element;
	 }
	
		
	
	  public static WebElement applyBt(WebDriver driver) 
	  {
	  element=driver.findElement(By.id("confirmSignature"));
	  										
	 return element; 
	 }
	  
	  public static WebElement drawSign(WebDriver driver) 
	  {
	  element=driver.findElement(By.xpath("//*[@id=\"signatureTab\"]/div/ul/li[2]"));
	
	  return element; 
	 }
	  
	  public static WebElement drawSignColor(WebDriver driver) 
	  {
	  element=driver.findElement(By.xpath("//*[@id=\"signatureDraw\"]/div[2]/div[3]"));
	
	  return element; 
	 }
	  
	  public static WebElement drawYourSign(WebDriver driver) 
	  {
	  element=driver.findElement(By.id("canvasSignature"));
	  
	  
	  return element; 
	 }
	  
	  public static WebElement deletDrawnSign(WebDriver driver) 
	  {
	  element=driver.findElement(By.id("canvasSignatureClean"));
	
	  return element; 
	 }

		/*
		 * public static WebElement applyDrawSign(WebDriver driver) {
		 * element=driver.findElement(By.id("confirmSignature"));
		 * 
		 * return element; }
		 */
		
	  public static WebElement uploadBt(WebDriver driver) 
	  {
	  element=driver.findElement(By.xpath("//*[@id=\"signatureTab\"]/div/ul/li[3]"));
	  return element; 
	 }
	  
	  
	  
	  
	  public static WebElement deletUploadedSign(WebDriver driver) 
	  {
	  element=driver.findElement(By.id("uploadSignatureImageClean"));
	  return element; 
	 }
	  public static WebElement uploadSignFile(WebDriver driver) 
	  {
	  element=driver.findElement(By.id("uploadSignatureImage"));
	  return element; 
	 }
	  

}
