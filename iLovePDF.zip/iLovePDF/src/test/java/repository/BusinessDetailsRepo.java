package repository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class BusinessDetailsRepo 
{
static WebElement element;
	
	public static void login(WebDriver driver) 
	{
		driver.get("https://www.ilovepdf.com/login");
	}

	public static WebElement email(WebDriver driver) 
	{
		element = driver.findElement(By.id("loginEmail"));
		return element;
	}

	public static WebElement pass(WebDriver driver) 
	{
		element = driver.findElement(By.id("inputPasswordAuth"));
		return element;
	}

	public static WebElement loginBT(WebDriver driver) 
	{
		element = driver.findElement(By.id("loginBtn"));
		return element;
	}
	
	public static WebElement myAc(WebDriver driver) 
	{
		element=driver.findElement(By.xpath("/html/body/div[1]/div/div[5]/ul/li[1]/a"));
		return element;
		
	}
	
	public static WebElement scrollDown(WebDriver driver) 
	{
		element=driver.findElement(By.linkText("Invoices"));
		return element;
		
	}
	
//	Business details(BD)
	public static WebElement clickBD(WebDriver driver) 
	{
		element=driver.findElement(By.linkText("Business details"));
		return element;
		
	}
	
	//billing-change-btn
	
	public static WebElement clickChangeForBD(WebDriver driver) 
	{
		element=driver.findElement(By.id("billing-change-btn"));
		return element;
		
	}
	
	//updatebillingform-company

	public static WebElement enterCompanyName(WebDriver driver) 
	{
		element=driver.findElement(By.id("updatebillingform-company"));
		return element;
		
	}
	
	public static WebElement enterVATid(WebDriver driver) 
	{
		element=driver.findElement(By.id("updatebillingform-vat_number"));
		return element;
		
	}
	
	public static WebElement enterCountry(WebDriver driver) 
	{
		element=driver.findElement(By.id("updatebillingform-country_id"));
		return element;
		
	}
	
	public static WebElement enterState(WebDriver driver) 
	{
		element=driver.findElement(By.id("updatebillingform-region"));
		return element;
		
	}
	public static WebElement enterCity(WebDriver driver) 
	{
		element=driver.findElement(By.id("updatebillingform-city"));
		return element;
		
	}
	
	public static WebElement enterAddress(WebDriver driver) 
	{
		element=driver.findElement(By.id("updatebillingform-address"));
		return element;
		
	}
	
	public static WebElement enterZipCode(WebDriver driver) 
	{
		element=driver.findElement(By.id("updatebillingform-zip"));
		return element;
		
	}
	
	
	
	public static WebElement clickSaveBt(WebDriver driver) 
	{
		element=driver.findElement(By.id("save-btn"));
		return element;
		
	}
	
	public static WebElement sucessfullMsg(WebDriver driver) 
	{
		element=driver.findElement(By.xpath("//*[@id=\"mainAdmin\"]/div[2]/div[2]/div/div[1]/ul/li"));
		return element;
		
	}
	
}
