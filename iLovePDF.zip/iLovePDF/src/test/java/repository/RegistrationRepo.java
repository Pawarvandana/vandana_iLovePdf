package repository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class RegistrationRepo
{
	static WebElement element;
	
	public static void wbLink(WebDriver driver) 
	{
		driver.get("https://www.ilovepdf.com/");
	}
	
	public  static WebElement singUpCL(WebDriver driver) 
	{
		element=driver.findElement(By.linkText("Sign up"));
		return element;
	}
	
	public static WebElement userName(WebDriver driver) 
	{
		element = driver.findElement(By.name("SignupForm[name]"));
		return element;
	}
	public static WebElement eMail(WebDriver driver) 
	{
		element=driver.findElement(By.id("signupEmail"));
		return element;
		
	}
	public static WebElement passWord(WebDriver driver) 
	{
		element= driver.findElement(By.xpath("//*[@id=\"password\"]"));
		return element;
	}
	
	public static WebElement registerBT(WebDriver driver) 
	{
	   element=	driver.findElement(By.id("registerButton"));
	    return element;
		
	}
	
	// /html/body/div/div/div/div/h2
	
	public static WebElement registredSuccessFully(WebDriver driver) 
	{
	   element=	driver.findElement(By.xpath("/html/body/div/div/div/div/h2"));
	    return element;
		
	}
	//btn btn--red
	
	public static WebElement startUsing(WebDriver driver) 
	{
	   element=	driver.findElement(By.className("btn btn--red"));
	    return element;
		
	}
	
	public static WebElement welcomeAdmin(WebDriver driver) 
	{
		element = driver.findElement(By.xpath("/html/body/div[1]/div/div[5]/ul/li[1]"));
		return element;
	}

	
	  public static WebElement logOut(WebDriver driver) 
	  { 
		  element=driver.findElement(By.linkText("Log Out")); 

		  return element;
	  }
	
}
