package checkingLoginTests;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import repository.LoginRepo;
import repository.RegistrationRepo;

import org.testng.annotations.BeforeTest;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.time.Duration;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;

public class RegistrationTestWithPoi 
{
	WebDriver driver;
	 @BeforeTest
	  public void beforeTest() throws Exception
	 {
		 WebDriverManager.chromedriver().setup();
		 driver=new ChromeDriver();
		 driver.manage().window().maximize();
		 Thread.sleep(2000);
		 
	  }

  @Test
  public void registration() throws Exception 
  {
	  
	  FileInputStream file= new FileInputStream("C:\\Users\\Admin\\Documents\\LoginREPO\\RegistrationPoi.xlsx");
      XSSFWorkbook w=new XSSFWorkbook(file);
			
      XSSFSheet s=w.getSheet("register");
      int rowSize =s.getLastRowNum();
      
     String Name=s.getRow(0).getCell(0).getStringCellValue();
	  String Email=s.getRow(0).getCell(1).getStringCellValue();
	  String  Password=s.getRow(0).getCell(2).getStringCellValue();
	  
	  RegistrationRepo.wbLink(driver);
	  RegistrationRepo.singUpCL(driver).click();
	  
	  for(int i=1; i<=rowSize; i++)
		{
	  		
			String UserName=s.getRow(i).getCell(0).getStringCellValue();
			String UserEmail=s.getRow(i).getCell(1).getStringCellValue();
			
			String userPassWord=s.getRow(i).getCell(2).getStringCellValue();
			
			try
			{
				
				RegistrationRepo.userName(driver).sendKeys(UserName);
				Thread.sleep(2000);
				RegistrationRepo.eMail(driver).sendKeys(UserEmail);
				Thread.sleep(2000);
				  RegistrationRepo.passWord(driver).sendKeys(userPassWord);
				  Thread.sleep(2000);
				  RegistrationRepo.registerBT(driver).click();
				  Thread.sleep(2000);
				  
				  System.out.println(RegistrationRepo.registredSuccessFully(driver).getText());
				  
				/* WebDriverWait wait=new WebDriverWait(driver, Duration.ofSeconds(30));
				 wait.until(ExpectedConditions.visibilityOf(RegistrationRepo.welcomeAdmin(driver)));
				 Thread.sleep(5000);
				 
				  System.out.println(RegistrationRepo.registredSuccessFully(driver).getText());
				  Thread.sleep(2000);
				  RegistrationRepo.startUsing(driver).click();
				  
				  Thread.sleep(5000);
				  s.getRow(i).createCell(3).setCellValue("Registred SuceessFully");
				  
				  Actions ac=new Actions(driver);
					
					ac.moveToElement(RegistrationRepo.welcomeAdmin(driver)).build().perform();
					Thread.sleep(2000);
					LoginRepo.logOut(driver).click();
					Thread.sleep(5000);
					RegistrationRepo.singUpCL(driver).click();*/
				
			}	
			catch (Exception e) 
			{
				System.out.println("\nInvalid Credentials");
				//s.getRow(i).createCell(3).setCellValue("Invalid credential. Not Register.");
				
			}
			RegistrationRepo.userName(driver).clear();
			RegistrationRepo.eMail(driver).clear();
			  RegistrationRepo.passWord(driver).clear();
			  Thread.sleep(2000);
			
		}
	  
	  //FileOutputStream out=new FileOutputStream("C:\\Users\\Admin\\Documents\\LoginREPO\\RegistrationPoi.xlsx");
		//w.write(out);
		Thread.sleep(3000);
  }
	
	  
  
 
  @AfterTest
  public void afterTest() 
  {
	  driver.close();
	  
	  
  }

}
