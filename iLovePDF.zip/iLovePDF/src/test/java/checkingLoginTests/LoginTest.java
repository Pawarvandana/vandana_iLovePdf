package checkingLoginTests;

import org.testng.annotations.Test;
import io.github.bonigarcia.wdm.WebDriverManager;
import repository.LoginRepo;
import org.testng.annotations.BeforeTest;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterTest;

public class LoginTest 
{
	WebDriver driver;
	
	 @BeforeTest
	  public void beforeTest() throws Exception 
	 {
		 WebDriverManager.chromedriver().setup();
		 driver =new ChromeDriver();
		 driver.manage().window().maximize();
	 }	
  @Test
  public void loginFn() throws Exception
  {
	  FileInputStream file= new FileInputStream("C:\\Users\\Admin\\Documents\\LoginREPO\\LoginPOI.xlsx");
      XSSFWorkbook w=new XSSFWorkbook(file);
      
			
      XSSFSheet s=w.getSheet("Sheet1");
      int rowSize =s.getLastRowNum();
      
      String name1=s.getRow(0).getCell(0).getStringCellValue();
	  String loc1=s.getRow(0).getCell(1).getStringCellValue();
	  
	  LoginRepo.WebLik(driver);
	  
		LoginRepo.login(driver).click();
	  
	  	for(int i=1; i<=rowSize; i++)
		{
	  		
			String userEmail=s.getRow(i).getCell(0).getStringCellValue();
			String Password=s.getRow(i).getCell(1).getStringCellValue();
			
			try
			{
				
				
				LoginRepo.email(driver).sendKeys(userEmail);
				LoginRepo.pass(driver).sendKeys(Password);
				LoginRepo.loginBT(driver).click();
				Thread.sleep(2000);
				
				Actions ac=new Actions(driver);
				
				ac.moveToElement(LoginRepo.welcomeAdmin(driver)).build().perform();
				Thread.sleep(2000);
				LoginRepo.logOut(driver).click();
				
				System.out.println("Valid username and password.");
				System.out.println("");
				
				s.getRow(i).createCell(2).setCellValue("Valid username and password.");
				
				LoginRepo.login(driver).click();
				
				
			}
			catch(Exception e) 
			{
				System.out.println("Invalid username or password");
				System.out.println("");
				s.getRow(i).createCell(2).setCellValue("Invalid username and password.");
			}
			
			LoginRepo.email(driver).clear();
			LoginRepo.pass(driver).clear();
			Thread.sleep(2000);
			
			
		}
		
		FileOutputStream out=new FileOutputStream("C:\\Users\\Admin\\Documents\\LoginREPO\\LoginPOI.xlsx");
		w.write(out);
		Thread.sleep(3000);
		
}
  @AfterTest
  public void afterTest() 
  {
	  driver.getTitle();
	  driver.close();
	  
  }

}
