package businessDetailsTest;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import repository.BusinessDetailsRepo;

import org.testng.annotations.BeforeTest;

import javax.swing.JOptionPane;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;

public class BusinessDetailsTestWithJOption 
{
	WebDriver driver;
	 @BeforeTest
	  public void beforeTest() 
	 {
		 WebDriverManager.edgedriver().setup();
		 driver=new EdgeDriver();
		 driver.manage().window().maximize();
		 
	  }
  @Test
  public void businessDetailsEdit() throws Exception
  {
	  String usn=JOptionPane.showInputDialog("Enter your valid email-ID: ");
	  String pwd=JOptionPane.showInputDialog("Enter your password");
	  BusinessDetailsRepo.login(driver);
	  BusinessDetailsRepo.email(driver).sendKeys(usn);
	  BusinessDetailsRepo.pass(driver).sendKeys(pwd);
	  BusinessDetailsRepo.loginBT(driver).click();
	  Thread.sleep(2000);
	  BusinessDetailsRepo.myAc(driver).click();
	  BusinessDetailsRepo.scrollDown(driver);
	  BusinessDetailsRepo.clickBD(driver).click();
	  Thread.sleep(2000);
	  BusinessDetailsRepo.clickChangeForBD(driver).click();
	  
	  String companyName=JOptionPane.showInputDialog("Enter Your Company Name:");
	  String vatID=JOptionPane.showInputDialog("Enter Your Company VAT-ID:");
	  String state=JOptionPane.showInputDialog("Enter your state:");
	  String city=JOptionPane.showInputDialog("Enter your city:");
	  String address=JOptionPane.showInputDialog("Enter your Address:");
	  String zipCode=JOptionPane.showInputDialog("Enter your ZipCode:");
	  
	  BusinessDetailsRepo.enterCompanyName(driver).clear();
	  BusinessDetailsRepo.enterCompanyName(driver).sendKeys(companyName);
	  
	  BusinessDetailsRepo.enterVATid(driver).clear();
	  BusinessDetailsRepo.enterVATid(driver).sendKeys(vatID);
	  
	  Select s=new Select(BusinessDetailsRepo.enterCountry(driver));
	  s.selectByVisibleText("India");
	 
	  BusinessDetailsRepo.enterState(driver).clear();
	  BusinessDetailsRepo.enterState(driver).sendKeys(state);
	  
	  BusinessDetailsRepo.enterCity(driver).clear();
	  BusinessDetailsRepo.enterCity(driver).sendKeys(city);
	  
	  BusinessDetailsRepo.enterAddress(driver).clear();
	  BusinessDetailsRepo.enterAddress(driver).sendKeys(address);
	  
	  	BusinessDetailsRepo.enterZipCode(driver).clear();
	  BusinessDetailsRepo.enterZipCode(driver).sendKeys(zipCode);
	  BusinessDetailsRepo.clickSaveBt(driver).click();
	  if(BusinessDetailsRepo.sucessfullMsg(driver).getText().contains("Your billing data has been updated."))
	  {
		  System.out.println("Success! Your billing data has been updated.");
	  }
  }
 

  @AfterTest
  public void afterTest() 
  {
	 driver.close();
	  
  }

}
