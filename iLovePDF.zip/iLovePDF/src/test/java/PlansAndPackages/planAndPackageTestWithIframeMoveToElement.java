package PlansAndPackages;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import repository.PlansAndPackages;

import org.testng.annotations.BeforeTest;

import java.io.IOException;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;

public class planAndPackageTestWithIframeMoveToElement
{
	WebDriver driver;
	 @BeforeTest
	  public void beforeTest() 
	 {
		 WebDriverManager.chromedriver().setup();
			driver=new ChromeDriver();
			driver.manage().window().maximize();
	  }

  @Test
  public void viewPlansAndPackage() throws Exception
  {
	  PlansAndPackages.login(driver);
	  PlansAndPackages.email(driver).sendKeys("Kajalpawar22@gmail.com");
	  PlansAndPackages.pass(driver).sendKeys("Kaju@22");
	  PlansAndPackages.loginBT(driver).click();
	  
	  Thread.sleep(2000);
	  
	  PlansAndPackages.myAc(driver).click();
	  PlansAndPackages.scrollDown(driver);
	  Thread.sleep(2000);
	  
	  PlansAndPackages.clickPlanPackage(driver).click();
	  Thread.sleep(2000);
	  PlansAndPackages.clickAddMoreSign(driver).click();
	   Thread.sleep(2000);
	  Actions ac=new Actions(driver);
	  
	  ac.moveToElement(PlansAndPackages.listSign1(driver)).click().build().perform();
	  Thread.sleep(1000);
	  
	  ac.moveToElement(PlansAndPackages.listSign2(driver)).click().build().perform();
	  Thread.sleep(1000);
	  ac.moveToElement(PlansAndPackages.listSign3(driver)).click().build().perform();
	  Thread.sleep(1000);
	  ac.moveToElement(PlansAndPackages.listSign4(driver)).click().build().perform();
	  Thread.sleep(1000);
	  ac.moveToElement(PlansAndPackages.listSign5(driver)).click().build().perform();
	  Thread.sleep(1000);
	  ac.moveToElement(PlansAndPackages.listSign6(driver)).click().build().perform();
	  Thread.sleep(1000);
	  ac.moveToElement(PlansAndPackages.listSign7(driver)).click().build().perform();
	  
	  PlansAndPackages.processToCheck(driver).click();
	  Thread.sleep(2000);
	  
	  System.out.println(PlansAndPackages.pay(driver).getText());
	  
	  driver.switchTo().frame(PlansAndPackages.payFrame(driver));
	  //PlansAndPackages.pay(driver).getText();
	  
	  
	  
	 String cardDetails=JOptionPane.showInputDialog("Enter your card number:");
	  JavascriptExecutor js=(JavascriptExecutor)driver;
	  
	  	  //js.executeScript("argument[0].value='cardDetails'"));
     // js.executeScript("document.getElementById('some id').value='someValue';");
	 //js.executeScript("arguments[0].value='cardDetails'", PlansAndPackages.cardNo(driver));
	  
	  PlansAndPackages.cardNo(driver).sendKeys(cardDetails);
	  Thread.sleep(2000);
	  driver.switchTo().parentFrame();
	  
	  PlansAndPackages.confirmPayment(driver).click();
	  
	  //PlansAndPackages.closeListSign(driver).click();
	  Thread.sleep(4000);
	  System.out.println( PlansAndPackages.confirmPayMsg(driver).getText());
	//  PlansAndPackages.confirmPayMsg(driver).getText();
	  Thread.sleep(2000);
	  PlansAndPackages.backToPayFram(driver).click();
	  Thread.sleep(2000);
	  js.executeScript("arguments[0].click();", PlansAndPackages.closePayFrame(driver));
//	  PlansAndPackages.closePayFrame(driver).click();
	  Thread.sleep(4000);
	  
	  PlansAndPackages.clickListSMS(driver).click();
	  Thread.sleep(2000);
	  System.out.println(PlansAndPackages.validationSMS(driver).getText());
	  ac.moveToElement(PlansAndPackages.listSMS1(driver)).click().build().perform();
	  Thread.sleep(1000);
	  ac.moveToElement(PlansAndPackages.listSMS2(driver)).click().build().perform();
	  
	  Thread.sleep(1000);
	  ac.moveToElement(PlansAndPackages.listSMS3(driver)).click().build().perform();
	  
	  Thread.sleep(1000);
	  ac.moveToElement(PlansAndPackages.listSMS4(driver)).click().build().perform();
	  Thread.sleep(1000);
	  ac.moveToElement(PlansAndPackages.listSMS5(driver)).click().build().perform();
	  
	  Thread.sleep(1000);
	  ac.moveToElement(PlansAndPackages.listSMS6(driver)).click().build().perform();
	  
	  Thread.sleep(1000);
	  ac.moveToElement(PlansAndPackages.listSMS7(driver)).click().build().perform();
	  Thread.sleep(2000);
	  
	 PlansAndPackages.closePayFrame(driver).click();
	 Thread.sleep(2000);
  }
 
  @AfterTest
  public void afterTest() 
  {
	  System.out.println("All digital signatures are Checked.");
	  System.out.println("All digital SMS are Checked. ");
	  driver.close();
	  
  }

}
