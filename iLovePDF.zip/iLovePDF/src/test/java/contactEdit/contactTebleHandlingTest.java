package contactEdit;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import repository.Contact;

import org.testng.annotations.BeforeTest;

import java.util.List;

import javax.swing.text.Element;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterTest;

public class contactTebleHandlingTest
{
	 WebDriver driver;
	
	 @BeforeTest
	  public void beforeTest() 
	 {
		 WebDriverManager.chromedriver().setup();
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		 
	  }

  @Test
  
  public void tebleHandling() throws Exception
  {
	  Contact.login(driver);
	  Contact.email(driver).sendKeys("kajalpawar22@gmail.com");
	  Contact.pass(driver).sendKeys("Kaju@22");
	  Contact.loginBT(driver).click();
	  Contact.myAc(driver).click();
	  Thread.sleep(2000);
	  
	  Actions action=new Actions(driver);
	  action.scrollToElement(Contact.scrollDown(driver)).build().perform();
	  Thread.sleep(2000);
	  
	  Contact.clickContact(driver).click();
	  Thread.sleep(2000); 
	  
		int cols_size = Contact.tableColumns(driver).size();
		int row_size = Contact.tableRow(driver).size();
		
		
		System.out.println("No. of columns are : "+cols_size);
		System.out.println();
		
		System.out.println("No. of rows are: "+row_size);
		System.out.println();
		
		for(int i=2; i<=row_size; i++)   //loop for rows
			
		{
			for (int j=2; j<=cols_size; j++ ) //loop for columns
		
			{
				System.out.println("\n" +Contact.table(driver,i,j).getText());
				
				
		    }
			
			Thread.sleep(5000);
			
			
		} 
		
	  
  }
 
  @AfterTest
  public void afterTest() 
  {
	  driver.close();
	  
  }

}
