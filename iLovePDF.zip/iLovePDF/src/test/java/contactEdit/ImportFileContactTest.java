package contactEdit;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import repository.Contact;

import org.testng.annotations.BeforeTest;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterTest;

public class ImportFileContactTest 
{
	WebDriver driver;
	
	 @BeforeTest
	  public void beforeTest() 
	 {
		 WebDriverManager.chromedriver().setup();
			driver=new ChromeDriver();
			driver.manage().window().maximize();
	  }

  @Test
  public void importContact() throws Exception
  {
	  Contact.login(driver);
	  Contact.email(driver).sendKeys("kajalpawar22@gmail.com");
	  Contact.pass(driver).sendKeys("Kaju@22");
	  Contact.loginBT(driver).click();
	  Contact.myAc(driver).click();
	  Thread.sleep(2000);
	  
	  Actions action=new Actions(driver);
	  action.scrollToElement(Contact.scrollDown(driver)).build().perform();
	  Thread.sleep(2000);
	  
	  Contact.clickContact(driver).click();
	  Thread.sleep(2000); 
	  Contact.impConFile(driver).click();
	 Contact.impConUpload(driver).click();
	 
	 Robot rb=new Robot();
	  
	  rb.delay(2000);
	  
	  StringSelection ss=new
	  StringSelection("C:\\Users\\Admin\\Desktop\\importContactiLovePdf.xlsx");
	 Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);
	  rb.keyPress(KeyEvent.VK_CONTROL);
	  
	  rb.keyPress(KeyEvent.VK_V); rb.delay(2000);
	  
	  rb.keyRelease(KeyEvent.VK_CONTROL); rb.keyRelease(KeyEvent.VK_V);
	  rb.delay(2000);
	  
	  rb.keyPress(KeyEvent.VK_ENTER); rb.keyRelease(KeyEvent.VK_ENTER);
	  rb.delay(2000);
	  
  }
 
  @AfterTest
  public void afterTest() throws Exception
  {
	  if(Contact.ConUploadedMSG(driver).getText().equalsIgnoreCase(" contacts are scheduled for import."))
	  {
		  System.out.println("Contact Imported.");
	  }
	  else if(Contact.ConNotUpload(driver).getText().contains(" contacts were ignored during the import."))
	  {
		  System.out.println("Duplicate Contact, Contact Not Imported.");
		
	}
	  
	  else
	  {
		  System.out.println("Contact Not Imported");
		
	}
	  Thread.sleep(2000);
	driver.close();
	  
	  
	  
  }

}
