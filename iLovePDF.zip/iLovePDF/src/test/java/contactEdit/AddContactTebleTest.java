package contactEdit;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import repository.Contact;

import org.testng.annotations.BeforeTest;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterTest;

public class AddContactTebleTest 
{
	WebDriver driver;
	@BeforeTest
	  public void beforeTest()
	{
		WebDriverManager.chromedriver().setup();
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		
	 }
	
  @Test
  public void addContactEditTable() throws Exception
  {
	  Contact.login(driver);
	  Contact.email(driver).sendKeys("kajalpawar22@gmail.com");
	  Contact.pass(driver).sendKeys("Kaju@22");
	  Contact.loginBT(driver).click();
	  Contact.myAc(driver).click();
	  Thread.sleep(2000);
	  
	  Actions action=new Actions(driver);
	  action.scrollToElement(Contact.scrollDown(driver)).build().perform();
	  Thread.sleep(2000);
	  
	  Contact.clickContact(driver).click();
	  Thread.sleep(2000);
	  Contact.addContact(driver).click();
	  Contact.conName(driver).sendKeys("Nirmala");
	  Contact.conEmail(driver).sendKeys("nirmala@gmail.com");
	  Contact.conPhone(driver).sendKeys("124578965");
	  Contact.contactCreate(driver).click();
	  
  }
  

  @AfterTest
  public void afterTest() throws Exception
  {
	  if(Contact.ConfirmConCreated(driver).getText().contains("1 contacts were created."))
	  {
		  System.out.println("New Contact Created");
	  }
	  
	  Thread.sleep(2000);
	  driver.close();
  }

}