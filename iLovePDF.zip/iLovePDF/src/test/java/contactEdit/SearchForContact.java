package contactEdit;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import repository.Contact;

import org.testng.annotations.BeforeTest;

import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterTest;

public class SearchForContact 
{
	WebDriver driver;
	 @BeforeTest
	  public void beforeTest() 
	 {
		 WebDriverManager.chromedriver().setup();
			driver=new ChromeDriver();
			driver.manage().window().maximize();
	  }
	@Test
  public void serchTheContacts() throws Exception
	{
		Contact.login(driver);
		  Contact.email(driver).sendKeys("kajalpawar22@gmail.com");
		  Contact.pass(driver).sendKeys("Kaju@22");
		  Contact.loginBT(driver).click();
		  Contact.myAc(driver).click();
		  Thread.sleep(2000);
		  
		  Actions action=new Actions(driver);
		  action.scrollToElement(Contact.scrollDown(driver)).build().perform();
		  Thread.sleep(2000);
		  
		  Contact.clickContact(driver).click();
		  Thread.sleep(2000); 
		
		  
		  FileInputStream file=new FileInputStream("C:\\Users\\Admin\\Documents\\LoginREPO\\LoginPOI.xlsx");
		  XSSFWorkbook xw=new XSSFWorkbook(file);
		  
		  XSSFSheet xs=xw.getSheet("DataForSearch");
		  int rowSize =xs.getLastRowNum();
		  
		  System.out.println("Number of rows: "+rowSize);
		  Contact.searchCon(driver);
		  for(int i=1; i<=rowSize; i++)
			{
				String dataSearch=xs.getRow(i).getCell(0).getStringCellValue();
				
					Contact.searchCon(driver).sendKeys(dataSearch);
					Contact.searchCon(driver).sendKeys(Keys.ENTER);
					Thread.sleep(3000);
					
					
					if(Contact.invalidData(driver).getText().equals("1-0 of 0"))
					{
						
						
					System.out.println("Invalid data." + " " +dataSearch);
					
					xs.getRow(i).createCell(1).setCellValue("Invalid user.");
					
					
					}
					
					else 
					{
						
						System.out.println("Valid data.");
						xs.getRow(i).createCell(1).setCellValue("Valid user.");
						
					}
					
					Contact.searchCon(driver).clear();	
				}
		  
		  
		  FileOutputStream out=new FileOutputStream("C:\\Users\\Admin\\Documents\\LoginREPO\\LoginPOI.xlsx");
		  xw.write(out);
		  Thread.sleep(2000);
				
		
	}
 

  @AfterTest
  public void afterTest() 
  {
	  driver.close();
	  
  }

}
