package contactEdit;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import repository.Contact;

import org.testng.annotations.BeforeTest;

import javax.swing.JOptionPane;

import org.openqa.selenium.Alert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;

public class SearchWithEditContact 
{ 
	WebDriver driver;
	@BeforeTest
	  public void beforeTest() 
	{
		WebDriverManager.chromedriver().setup();
		driver=new ChromeDriver();
		driver.manage().window().maximize();
	  }
  @Test
  public void searchEditContact() throws Exception
  {
	  Contact.login(driver);
	  Contact.email(driver).sendKeys("kajalpawar22@gmail.com");
	  Contact.pass(driver).sendKeys("Kaju@22");
	  Contact.loginBT(driver).click();
	  Contact.myAc(driver).click();
	  Thread.sleep(2000);
	  
	  Actions action=new Actions(driver);
	  action.scrollToElement(Contact.scrollDown(driver)).build().perform();
	  Thread.sleep(2000);
	  
	  Contact.clickContact(driver).click();
	  Thread.sleep(2000);
	  Contact.searchCon(driver).sendKeys("Ravi");
	  Contact.searchCon(driver).sendKeys(Keys.ENTER);
	  Thread.sleep(2000);
	  if(Contact.editContactInfo(driver).getText().contains("Contacts"));
	  {
		  
		  Contact.editContactBT(driver).click();
		  
		  Contact.contactInfoChange(driver).click();
		  if(Contact.contactInfoChangeWindow(driver).isDisplayed())
		  {
		  Contact.contactInfoChangeName(driver).clear();
		  Contact.contactInfoChangeName(driver).sendKeys("Rutuja");
		  Thread.sleep(2000);
		  
		  //Actions act=new Actions(driver);
		  //act.moveToElement(Contact.contactInfoChangeSaveBt(driver)).click().build().perform();
		 JavascriptExecutor jse=(JavascriptExecutor)driver;
		 jse.executeScript("arguments[0].click();", Contact.contactInfoChangeSaveBt(driver));
		  Thread.sleep(5000);
		  System.out.println(Contact.contactInfoChangeSuccessMsg(driver).getText());
		  jse.executeScript("arguments[0].click();", Contact.backToContactSearchPg(driver));
		// Contact.backToContactSearchPg(driver).click();
		 Thread.sleep(5000);
		 
		 String searchContact=JOptionPane.showInputDialog("Search For Contact: ");
		  Contact.searchCon(driver).sendKeys(searchContact);
		  Thread.sleep(2000);
		  Contact.deleteSearchedCon(driver).click();
		  Thread.sleep(2000);
		
		 //Contact.doNotDelete(driver).click();
		 //System.out.println(Contact.doNotDelete(driver).getText());
		 Contact.yesDelete(driver).click();
		 System.out.println(Contact.contactRemoved(driver).getText());
		 Thread.sleep(2000);
		  
		 if  (Contact.noDataAvailabel(driver).isDisplayed()) 
		  {
			System.out.println("No data Available ");
		}
		  
		}
		  
	  }
	  
	  
	  
  }
  

  @AfterTest
  public void afterTest() 
  {
	  driver.close();
  }

}
