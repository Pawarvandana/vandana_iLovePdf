package myAccountUsingDropDown;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import repository.MyAccountChangesRepo;

import org.testng.annotations.BeforeTest;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;

public class EmailTest 
{
	WebDriver driver;
	
	 @BeforeTest
	  public void beforeTest()
	 {
		 WebDriverManager.chromedriver().setup();
			driver=new ChromeDriver();
			driver.manage().window().maximize();
	 }

  @Test
  public void emailEdit() throws Exception
  {
		 
	  MyAccountChangesRepo.logIn(driver);
	  MyAccountChangesRepo.un(driver).sendKeys("Kajalpawar22@gmail.com");
	  MyAccountChangesRepo.pwd(driver).sendKeys("Kaju@22");
	  
	  MyAccountChangesRepo.logInBT(driver).click();
	  Thread.sleep(1000);
	  
	  MyAccountChangesRepo.myAc(driver).click();
	  MyAccountChangesRepo.emailEditBt(driver).click();
	  
	 // Actions ac=new Actions(driver);
	 // ac.scrollToElement(MyAccountChangesRepo.scrollToBottom(driver)).build().perform();
	  JavascriptExecutor j=(JavascriptExecutor)driver;
	  j.executeScript("window.scrollTo(0, document.body.scrollHeight)");
	  
	  MyAccountChangesRepo.currentPass(driver).sendKeys("Kaju@222");
	  Thread.sleep(2000);
	  MyAccountChangesRepo.newEmail(driver).sendKeys("Kajalpawar22@gmail.com");
	  Thread.sleep(2000);
	  MyAccountChangesRepo.reEnterNewEmail(driver).sendKeys("Kajalpawar22@gmail.com");
	  Thread.sleep(4000);
	  
	  j.executeAsyncScript("arguments[0].click();", MyAccountChangesRepo.saveBtEmail(driver));
	  //MyAccountChangesRepo.saveBtEmail(driver).click();
	  
	  System.out.println(MyAccountChangesRepo.updateEmail(driver).getText());
	 
	  Thread.sleep(5000);
	  
  }
 
  @AfterTest
  public void afterTest() 
  {
	  driver.close();
	  
  }

}
