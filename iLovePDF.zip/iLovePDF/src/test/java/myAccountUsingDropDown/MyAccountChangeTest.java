package myAccountUsingDropDown;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import repository.MyAccountChangesRepo;
import java.sql.Driver;
import java.util.Scanner;

import org.testng.annotations.BeforeTest;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;

public class MyAccountChangeTest 
{
	WebDriver driver;
	 String uname;
	 String pass;
	 
	@BeforeTest
	  public void beforeTest() 
	{
		Scanner sc=new Scanner(System.in);
		 
		 System.out.println("Enter email ID: ");
		 uname=sc.next();
		 
		 
		System.out.println("Enter password: ");
		pass=sc.next();
		 
		WebDriverManager.chromedriver().setup();
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		
	}
  @Test
  public void ChangesInMyAC() throws Exception
  {
	  
	    
		 
	  MyAccountChangesRepo.logIn(driver);
	  MyAccountChangesRepo.un(driver).sendKeys(uname);
	  MyAccountChangesRepo.pwd(driver).sendKeys(pass);
	  
	  MyAccountChangesRepo.logInBT(driver).click();
	  Thread.sleep(1000);
	  
	  MyAccountChangesRepo.myAc(driver).click();
	 MyAccountChangesRepo.clickChange(driver).click();
	 Thread.sleep(2000);
	 
	 JavascriptExecutor js=(JavascriptExecutor)driver;
		
	  js.executeScript("arguments[0].scrollIntoView();", MyAccountChangesRepo.scrollTo(driver));
	
	// MyAccountChangesRepo.scrollTo(driver);
	 Thread.sleep(2000);
	 MyAccountChangesRepo.profileName(driver).clear();
	 MyAccountChangesRepo.profileSurname(driver).clear();
	 
	 Thread.sleep(2000);
	 MyAccountChangesRepo.profileName(driver).sendKeys("Vandana");
	 MyAccountChangesRepo.profileSurname(driver).sendKeys("Ahire");
	 
	  Select s=new Select(MyAccountChangesRepo.country(driver));
	  s.selectByVisibleText("India");
	  Thread.sleep(2000);
	 //MyAccountChangesRepo.country(driver);
	  s=new Select(MyAccountChangesRepo.timeZone(driver));
	  s.selectByIndex(1);
	 // MyAccountChangesRepo.timeZone(driver);
	 MyAccountChangesRepo.saveBtn(driver).click();
	 Thread.sleep(2000);
	 System.out.println(MyAccountChangesRepo.msg(driver).getText());
	 
	  
  }
  

  @AfterTest
  public void afterTest() throws Exception
  {
		
	  if(MyAccountChangesRepo.msg(driver).isDisplayed())
	  {
		  System.out.println("Information Updated.");
	  }
	  Thread.sleep(2000);
	 	 
	  driver.close();
	  
		
	  
  }

}
